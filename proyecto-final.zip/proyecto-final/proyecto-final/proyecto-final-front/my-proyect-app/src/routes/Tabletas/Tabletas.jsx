const Tabletas = () => {
    return (
        <h1>Tabletas</h1>
    )};
  
export default Tabletas;