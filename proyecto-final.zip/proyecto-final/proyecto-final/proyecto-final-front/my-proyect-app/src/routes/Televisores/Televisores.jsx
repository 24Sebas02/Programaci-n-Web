const Televisores = () => {
    return (
    <h1>Televisores</h1>
    )};
  
export default Televisores;
  