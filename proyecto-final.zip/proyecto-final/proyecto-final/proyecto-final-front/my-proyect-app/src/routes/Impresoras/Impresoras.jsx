const Impresoras = () => {
    return (
        <h1>Impresoras</h1>
    )};
  
export default Impresoras;