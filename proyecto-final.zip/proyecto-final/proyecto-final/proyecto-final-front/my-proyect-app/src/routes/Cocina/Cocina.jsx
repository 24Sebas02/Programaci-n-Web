const Cocina = () => {
    return (
        <h1>Utiles de Cocina</h1>
    )};
  
export default Cocina;