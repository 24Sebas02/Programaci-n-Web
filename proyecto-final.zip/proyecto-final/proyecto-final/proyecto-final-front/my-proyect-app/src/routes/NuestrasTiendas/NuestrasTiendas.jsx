const NuestrasTiendas = () => {
    return (
        <h1>Nuestras Tiendas</h1>
    )};
  
export default NuestrasTiendas;