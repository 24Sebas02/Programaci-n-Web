const Arte = () => {
    return (
        <h1>Arte</h1>
    )};
  
export default Arte;