const ElectroHogar = () => {
    return (
        <h1>ElectroHogar</h1>
    )};
  
export default ElectroHogar;