const TopOfertas = () => {
    return (
        <h1>Top Ofertas</h1>
    )};
  
export default TopOfertas;