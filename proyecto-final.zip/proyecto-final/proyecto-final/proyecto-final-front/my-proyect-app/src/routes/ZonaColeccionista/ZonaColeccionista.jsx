const ZonaColeccionista = () => {
    return (
        <h1>Zona Coleccionista</h1>
    )};
  
export default ZonaColeccionista;