const VentasCorporativas = () => {
    return (
        <h1>Ventas Corporativas</h1>
    )};
  
export default VentasCorporativas;