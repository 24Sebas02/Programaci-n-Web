const Laptops = () => {
    return (
        <h1>Laptops</h1>
    )};
  
export default Laptops;