import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import MainPage from './components/MainPage/MainPage.jsx';

function App() {
  return (
    
    <MainPage />
  );
}

export default App;


