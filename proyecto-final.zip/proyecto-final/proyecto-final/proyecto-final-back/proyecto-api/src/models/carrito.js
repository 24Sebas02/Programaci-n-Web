const carrito = {
    items: [], // Aquí irán los productos del carrito
    subtotal: 0, // Subtotal de los productos en el carrito
};
  
export default carrito;
  